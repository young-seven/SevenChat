import { db, auth } from "./firebase.js";

import {
  collection,
  getDocs,
  addDoc,
  serverTimestamp,
  query,
  where
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

const searchInput = document.getElementById("searchInput");
const chatList = document.getElementById("chatList");

let users = [];

// Load all users
async function loadUsers() {
  
  const snapshot = await getDocs(collection(db, "users"));
  
  users = [];
  
  snapshot.forEach((doc) => {
    
    console.log("Loaded user:", doc.id, doc.data());
    
    users.push({
      id: doc.id,
      ...doc.data()
    });
    
  });
  
  console.log("All users:", users);
  
  }
loadUsers();

// Search while typing
searchInput.addEventListener("input", () => {
  
  const text = searchInput.value.toLowerCase().trim();
  
  chatList.innerHTML = "";
  
  if (text === "") {
    
    chatList.innerHTML = `
      <div class="emptyChats">
        <div class="emptyIcon">💬</div>
        <h2>No conversations yet</h2>
        <p>Search for someone and start chatting.</p>
      </div>
    `;
    
    return;
  }
  
  users.forEach((user) => {
    
    if (
      auth.currentUser &&
      user.id === auth.currentUser.uid
    ) return;
    
    const username = (user.username || "").toLowerCase();
    
    if (username.includes(text)) {
      
      const card = document.createElement("div");
      
      card.className = "userCard";
      
      card.innerHTML = `
        <img src="images/avatars/${user.avatar}" class="userAvatar">

        <div class="userInfo">

          <h3>${user.username}</h3>

          <p>${user.online ? "🟢 Online" : "⚪ Offline"}</p>

        </div>

        <button class="startChatBtn">
          Chat
        </button>
      `;
      
      const chatBtn = card.querySelector(".startChatBtn");
      chatBtn.addEventListener("click", () => {
      createChat(user.id);
  
});
      
      chatList.appendChild(card);
      
    }
    
  });
  
});

async function createChat(otherUserId){
  const currentUser = auth.currentUser;
  if(!currentUser){

    alert("Please login again");
    return;

  }
  try{
    const chatKey = 
    [currentUser.uid, otherUserId]
    .sort()
    .join("_");
    // CHECK EXISTING CHAT
    const chatQuery = query(
      collection(db,"chats"),
      where("chatKey","==",chatKey)
    );
    const existingChats = await getDocs(chatQuery);
    // IF CHAT EXISTS
    if(!existingChats.empty){
      const existingChat =
      existingChats.docs[0];
      window.location.href =
      `chat.html?chatId=${existingChat.id}`;
      return;
    }
    // CREATE NEW CHAT
    const newChat = await addDoc(
      collection(db,"chats"),
      {
        chatKey: chatKey,
        participants:{
          [currentUser.uid]:true,
          [otherUserId]:true
        },
        lastMessage:"",
        createdAt:serverTimestamp()
      }
    );
    window.location.href =
    `chat.html?chatId=${newChat.id}`;
  }catch(error){
    console.log(error);
    alert(error.message);


  }

}